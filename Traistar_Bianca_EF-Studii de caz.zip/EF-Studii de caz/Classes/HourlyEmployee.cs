﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EF_Studii_de_caz.Classes
{
    public class HourlyEmployee : Employee
    {
        public decimal? Wage { get; set; }
    }
}
